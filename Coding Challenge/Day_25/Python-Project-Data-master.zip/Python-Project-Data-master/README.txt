Please Download Data for Human Activity Recognition Project
